var searchData=
[
  ['tablac_11',['tablaC',['../_ecuacion_8c.html#a6c36bf9ea41c1a3d85655ecf720de1bf',1,'tablaC(int r1, int r2, int m, int b):&#160;Ecuacion.c'],['../_ecuacion_8h.html#a6c36bf9ea41c1a3d85655ecf720de1bf',1,'tablaC(int r1, int r2, int m, int b):&#160;Ecuacion.c']]]
];
