var searchData=
[
  ['ecuacion_2ec_0',['Ecuacion.c',['../_ecuacion_8c.html',1,'']]],
  ['ecuacion_2eh_1',['Ecuacion.h',['../_ecuacion_8h.html',1,'']]]
];
