var searchData=
[
  ['ecuacion_2ec_7',['Ecuacion.c',['../_ecuacion_8c.html',1,'']]],
  ['ecuacion_2eh_8',['Ecuacion.h',['../_ecuacion_8h.html',1,'']]]
];
