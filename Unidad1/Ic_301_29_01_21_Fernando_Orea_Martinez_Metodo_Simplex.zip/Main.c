#include<stdio.h>
#include "Metodo Simplex.h"


	int main(void) {
		
		
Data();
Simplex();
Results();

	
	return 0;
}
