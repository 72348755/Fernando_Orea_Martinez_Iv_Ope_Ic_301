#include<stdio.h>

void Data();
void Pivot();
void Formula();
void Optimize();
void Simplex();
void Results();
